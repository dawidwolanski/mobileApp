package com.example.apka

data class Word (
    val id: Int,
    val wordPl: String,
    val wordEn: String,
    val level: Int
)